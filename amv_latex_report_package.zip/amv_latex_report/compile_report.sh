#!/usr/bin/env bash
set -e
pdflatex -interaction=nonstopmode -halt-on-error amv_report.tex
pdflatex -interaction=nonstopmode -halt-on-error amv_report.tex
